import React from 'react';
import Transfer from './Transfer';

function App() {
  return (
    <div className="App">
      <Transfer />
    </div>
  );
}

export default App;
