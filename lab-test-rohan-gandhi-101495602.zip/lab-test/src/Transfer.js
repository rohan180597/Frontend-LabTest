import React, { useState } from 'react';
import Receipt from './Receipt';

function Transfer() {
  const [amount, setAmount] = useState('');
  const [senderAddress, setSenderAddress] = useState('0x255c6F15AE88C71C37c847d53d6eE67029B4F59c');
  const [receiverAddress, setReceiverAddress] = useState('00xAceBabe64807cb045505b268ef253D8fC2FeF5Bc');
  const [showReceipt, setShowReceipt] = useState(false);

  const handleAmountChange = (e) => {
    setAmount(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowReceipt(true);
  };

  return (
    <div>
      <h1>Transfer</h1>
      <p>Sender Address: {senderAddress}</p>
      <p>Receiver Address: {receiverAddress}</p>
      <form onSubmit={handleSubmit}>
        <label>
          Amount:
          <input type="text" value={amount} onChange={handleAmountChange} />
        </label>
        <button type="submit">Submit</button>
      </form>
      {showReceipt && (
        <Receipt
          amount={amount}
          senderAddress={senderAddress}
          receiverAddress={receiverAddress}
        />
      )}
    </div>
  );
}

export default Transfer;
