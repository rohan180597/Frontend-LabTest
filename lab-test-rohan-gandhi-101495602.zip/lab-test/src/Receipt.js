import React from 'react';

function Receipt({ amount, senderAddress, receiverAddress }) {
  const transactionHash = '6146ccf6a66d994f7c363db875e31ca35581450a4bf6d3be6cc9ac79233a69d0';
  const blockHash = '0xfe88c94d860f01a17f961bf4bdfb6e0c6cd10d3fda5cc861e805ca1240c58553';
  const blockNumber = 1; 
  const gasUsed = 21000;

  return (
    <div>
      <h2>Receipt </h2>
      <p>Amount : {amount}</p>
      <p>Sender Address: {senderAddress}</p>
      <p>Receiver Address: {receiverAddress}</p>
      <p>Transaction Hash: {transactionHash}</p>
      <p>Block Hash: {blockHash}</p>
      <p>Block Number: {blockNumber}</p>
      <p>Gas Used: {gasUsed}</p>
    </div>
  );
}

export default Receipt;

